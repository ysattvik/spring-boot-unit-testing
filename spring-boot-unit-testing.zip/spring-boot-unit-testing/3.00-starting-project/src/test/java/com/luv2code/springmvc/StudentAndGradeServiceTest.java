package com.luv2code.springmvc;

import com.luv2code.springmvc.models.*;
import com.luv2code.springmvc.repository.HistoryGradesDao;
import com.luv2code.springmvc.repository.MathGradesDao;
import com.luv2code.springmvc.repository.ScienceGradesDao;
import com.luv2code.springmvc.repository.StudentDao;
import com.luv2code.springmvc.service.StudentAndGradeService;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.jdbc.Sql;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

@TestPropertySource("/application-test.properties")
@SpringBootTest
public class StudentAndGradeServiceTest {

    @Autowired
    private JdbcTemplate jdbc;

    @Autowired
   private StudentAndGradeService studentService;

    @Autowired
    private StudentDao studentDao;

    @Autowired
    private MathGradesDao mathGradeDao;

    @Autowired
    private ScienceGradesDao scienceGradeDao;

    @Autowired
    private HistoryGradesDao historyGradeDao;

    @Value( "${sql.script.create.student}")
    private String sqlAddStudent;

    @Value( "${sql.script.create.math.grade}")
    private String sqlAddMathGrade;

    @Value( "${sql.script.create.science.grade}")
    private String sqlAddScienceGrade;

    @Value( "${sql.script.create.history.grade}")
    private String sqlAddHistoryGrade;

    @Value( "${sql.script.delete.student}")
    private String sqlDeleteStudent;

    @Value( "${sql.script.delete.math.grade}")
    private String sqlDeleteMathGrade;

    @Value( "${sql.script.delete.science.grade}")
    private String sqlDeleteScienceGrade;

    @Value( "${sql.script.delete.history.grade}")
    private String sqlDeleteHistoryGrade;

    @BeforeEach
    public void setupDatabase() {
//        jdbc.execute("insert into student (firstname, lastname, email_address) " +
//                "values ('Eric', 'Roby', 'eric.roby@gmail.com')");
//        jdbc.execute("insert into math_grade(student_id, grade)" +
//                "values (1, 100.00)");
//        jdbc.execute("insert into science_grade(student_id, grade)" +
//                "values (1, 100.00)");
//        jdbc.execute("insert into history_grade(student_id, grade)" +
//                "values (1, 100.00)");

        jdbc.execute(sqlAddStudent);
        jdbc.execute(sqlAddMathGrade);
        jdbc.execute(sqlAddScienceGrade);
        jdbc.execute(sqlAddHistoryGrade);
    }

    @Test
    public void createStudentService() {
        studentService.createStudent("Chad", "Darvy", "chad.darvy@gmail.com");

        CollegeStudent student = studentDao.findByEmailAddress("chad.darvy@gmail.com");

        assertEquals("chad.darvy@gmail.com", student.getEmailAddress(), "find by email");
    }

    @Test
    public void isStudentNullCheck() {
        assertTrue(studentService.checkIfStudentIsNull(1));
        assertFalse(studentService.checkIfStudentIsNull(0));
    }

    @Test
    public void deleteStudentService() {
        Optional<CollegeStudent> deletedStudent = studentDao.findById(1);
        Optional<MathGrade> deletedMathGrade = mathGradeDao.findById(1);
        Optional<ScienceGrade> deletedScienceGrade = scienceGradeDao.findById(1);
        Optional<HistoryGrade> deletedHistoryGrade = historyGradeDao.findById(1);

        assertTrue(deletedStudent.isPresent(), "Return true if student is present");
        assertTrue(deletedMathGrade.isPresent(), "Return true if math grade is present");
        assertTrue(deletedScienceGrade.isPresent(), "Return true if science grade is present");
        assertTrue(deletedHistoryGrade.isPresent(), "Return true if history grade is present");

        studentService.deleteStudent(1);

        deletedStudent = studentDao.findById(1);
        deletedHistoryGrade = historyGradeDao.findById(1);
        deletedScienceGrade = scienceGradeDao.findById(1);
        deletedMathGrade = mathGradeDao.findById(1);

        assertFalse(deletedStudent.isPresent(), "Return false if student is not present");
        assertFalse(deletedHistoryGrade.isPresent(), "Return false if history grade is not present");
        assertFalse(deletedScienceGrade.isPresent(), "Return false if science grade is not present");
        assertFalse(deletedMathGrade.isPresent(), "Return false if math grade is not present");
    }

    @Sql("/insertData.sql")
    @Test
    public void getGradeBookService() {
        Iterable<CollegeStudent> iterableCollegeStudents = studentService.getGradeBook();

        List<CollegeStudent> collegeStudents = new ArrayList<>();
        for (CollegeStudent i : iterableCollegeStudents) {
            collegeStudents.add(i);
        }

        assertEquals(5, collegeStudents.size(), "Return 1 student");
    }


    @Test
    public void createGradeService () throws Exception {

        //create the grade
        assertTrue(studentService.createGrade(80.50, 1, "math"));
        assertTrue(studentService.createGrade(80.50, 1, "science"));
        assertTrue(studentService.createGrade(80.50, 1, "history"));

        //Get all grades with studentId
        Iterable<MathGrade> mathGrades = mathGradeDao.findGradeByStudentId(1);
        Iterable<ScienceGrade> scienceGrades = scienceGradeDao.findGradeByStudentId(1);
        Iterable<HistoryGrade> historyGrades = historyGradeDao.findGradeByStudentId(1);

//        //Verify there are grades
//        assertTrue(mathGrades.iterator().hasNext());
//        assertTrue(scienceGrades.iterator().hasNext());
//        assertTrue(historyGrades.iterator().hasNext());


        assertTrue(((Collection<MathGrade>) mathGrades).size() == 2, "Student has math grades");
        assertTrue(((Collection<ScienceGrade>) scienceGrades).size() == 2, "Student has science grades");
        assertTrue(((Collection<HistoryGrade>) historyGrades).size() == 2, "Student has history grades");;
    }

    @Test
    public void createGradeServiceReturnFalse () throws Exception {
        assertFalse(studentService.createGrade(105.0, 1, "math"));
        assertFalse(studentService.createGrade(-1.0, 1, "math"));
        assertFalse(studentService.createGrade(80.50, 2, "math"));
        assertFalse(studentService.createGrade(80.50, 1, "literature"));

    }

    @Test
    public void deleteGradeService () throws Exception {
        assertEquals(1, studentService.deleteGrade(1, "math"), "Return Student Id after delete");
        assertEquals(1, studentService.deleteGrade(1, "science"), "Return Student Id after delete");
        assertEquals(1, studentService.deleteGrade(1, "history"), "Return Student Id after delete");

    }

    @Test
    public void deleteGradeServiceReturnStudentIdOfZero () throws Exception {
            assertEquals(0, studentService.deleteGrade(0, "science"), "No Student should have 0 id");
            assertEquals(0, studentService.deleteGrade(1, "literature"), "No Student should have literature class");
    }

    @Test
    public void testStudentInformation() {
        GradebookCollegeStudent gradebookCollegeStudent = studentService.studentInformation(1);

        assertNotNull(gradebookCollegeStudent);
        assertEquals(1, gradebookCollegeStudent.getId());
        assertEquals("Eric", gradebookCollegeStudent.getFirstname());
        assertEquals("Roby", gradebookCollegeStudent.getLastname());
        assertEquals("eric.roby@gmail.com", gradebookCollegeStudent.getEmailAddress());
        assertTrue(gradebookCollegeStudent.getStudentGrades().getMathGradeResults().size() == 1);
        assertTrue(gradebookCollegeStudent.getStudentGrades().getScienceGradeResults().size() == 1);
        assertTrue(gradebookCollegeStudent.getStudentGrades().getHistoryGradeResults().size() == 1);
    }

    @Test
    public void studentInformationReturnNull() {
        GradebookCollegeStudent gradebookCollegeStudent = studentService.studentInformation(0);
        assertNull(gradebookCollegeStudent, "No student should have 0 id");
    }

    @AfterEach
    public void setupAfterTransaction() {
//        jdbc.execute("DELETE FROM student");
//        jdbc.execute("DELETE FROM math_grade");
//        jdbc.execute("DELETE FROM science_grade");
//        jdbc.execute("DELETE FROM history_grade");
//        jdbc.execute("ALTER TABLE student ALTER COLUMN ID RESTART WITH 1");
//        jdbc.execute("ALTER TABLE math_grade ALTER COLUMN ID RESTART WITH 1");
//        jdbc.execute("ALTER TABLE science_grade ALTER COLUMN ID RESTART WITH 1");
//        jdbc.execute("ALTER TABLE history_grade ALTER COLUMN ID RESTART WITH 1");
//
        jdbc.execute(sqlDeleteStudent);
        jdbc.execute(sqlDeleteMathGrade);
        jdbc.execute(sqlDeleteScienceGrade);
        jdbc.execute(sqlDeleteHistoryGrade);
    }
}
