package com.luv2code.springmvc.models;

public interface Student {

   String studentInformation();

   String getFullName();

}
