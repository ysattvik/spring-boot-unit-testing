INSERT INTO student(id,firstname,lastname,email_address) VALUES (11, 'John', 'One', 'john.one@gmail.com');
INSERT INTO student(id,firstname,lastname,email_address) VALUES (12, 'John', 'Two', 'john.two@gmail.com');
INSERT INTO student(id,firstname,lastname,email_address) VALUES (13, 'John', 'Three', 'john.three@gmail.com');
INSERT INTO student(id,firstname,lastname,email_address) VALUES (14, 'John', 'Four', 'john.four@gmail.com');