package com.luv2code.junitdemo;

import org.junit.jupiter.api.*;

import java.time.Duration;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

//@DisplayNameGeneration(DisplayNameGenerator.ReplaceUnderscores.class)
//@TestMethodOrder(MethodOrderer.MethodName.class)
//@TestMethodOrder(MethodOrderer.DisplayName.class)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class DemoUtilsTest {
    DemoUtils demoUtils;

    @BeforeEach
    void setupBeforeEach() {
        demoUtils = new DemoUtils();
//        System.out.println("@BeforeEach executes before the execution of each test method ");
    }

     /*
    @AfterEach
    void afterEach() {
        System.out.println("@AfterEach executes after the execution of each test method \n");
    }

    @BeforeAll
    static void setupStaticBeforeEach() {
        System.out.println("@BeforeAll executes only once before the execution of all test methods ");
    }

    @AfterAll
    static void setupStaticAfterEach() {
        System.out.println("@AfterAll executes only once after the execution of all test methods ");
    }

     */

    @DisplayName("Multiply")
    @Test
    void testMultiply() {
        assertEquals(8, demoUtils.multiply(4,2), "4*2 should be 8");
    }

    @Test
    @DisplayName("Equals and Not Equals")
    @Order(1)
    void tesEqualsAndNotEquals() {

//        System.out.println("Running Test : testEqualsAndNotEquals ");

        assertEquals(6, demoUtils.add(2, 4), "2+4 must be 6");
        assertNotEquals(6, demoUtils.add(2, 5), "2+5 must not be 6");

    }

    @Test
    @DisplayName("Null and Not Null")
    @Order(0)
    void testNullAndNotNull() {
//        System.out.println("Running Test : testNullAndNotNull ");

        String str = null;
        String str2 = "Hello World";

        assertNull(demoUtils.checkNull(str), "Object should be null");
        assertNotNull(demoUtils.checkNull(str2), "Object should not be null");
    }

    @Test
    @DisplayName("Same and Not Same")
    void testSameAndNotSame() {
        String str1 = "luv2code";
        assertSame(demoUtils.getAcademy(), demoUtils.getAcademyDuplicate(), "Object should be same");
        assertNotSame(str1, demoUtils.getAcademy(), "Object should not be same");
    }

    @Test
    @DisplayName("True and False")
    @Order(30)
    void testTrueAndFalse() {
        int gradeOne = 10;
        int gradeTwo = 5;
        assertTrue(demoUtils.isGreater(gradeOne, gradeTwo), "This should be true");
        assertFalse(demoUtils.isGreater(gradeTwo, gradeOne), "This should be false");
    }

    @Test
    @DisplayName("Array Equals")
    void testArrayEquals() {
        String[] firstArray = {"A", "B", "C"};
        assertArrayEquals(firstArray, demoUtils.getFirstThreeLettersOfAlphabet(), "Arrays should be equal");
    }

    @DisplayName("Iterable Equals")
    @Test
    void testIterableEquals() {
        List<String> firstList = List.of("luv", "2", "code");

        assertIterableEquals(firstList, demoUtils.getAcademyInList(), "Excepted Lists should be same as actual list");
    }

    @DisplayName("Lines Match")
    @Test
    @Order(50)
    void testLinesMatch () {
            List<String> firstList = List.of("luv", "2", "code");

            assertLinesMatch(firstList, demoUtils.getAcademyInList(), "Excepted Lists should be same as actual list");
    }

    @DisplayName("Throws and Does Not Throw")
    @Test
    void testThrowsAndDoesNotThrow() {
        assertThrows(Exception.class, () -> {demoUtils.throwException(-1);}, "Exception should be thrown");
        assertDoesNotThrow(() -> demoUtils.throwException(5), "Exception should not be thrown");
    }

    @DisplayName("Timeout")
    @Test
    void testTimeout() throws InterruptedException {
        assertTimeoutPreemptively(Duration.ofSeconds(3), () -> demoUtils.checkTimeout(),
                "Method should execute within 3 seconds");

    }
}
