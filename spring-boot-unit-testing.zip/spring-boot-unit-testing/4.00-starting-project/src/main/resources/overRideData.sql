UPDATE student SET firstname = 'Eric' WHERE id = 11;
UPDATE student SET lastname = 'Roby' WHERE id = 11;