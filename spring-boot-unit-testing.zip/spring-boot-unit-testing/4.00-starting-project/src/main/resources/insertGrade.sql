
insert into math_grade(id,student_id,grade) values (11,11,100.00)
    insert into math_grade(id,student_id,grade) values (12,11,95.00)

insert into math_grade(id,student_id,grade) values (13,12,83.25)
insert into math_grade(id,student_id,grade) values (14,12,79.67)

insert into math_grade(id,student_id,grade) values (15,13,81.80)
insert into math_grade(id,student_id,grade) values (16,13,100.00)

insert into math_grade(id,student_id,grade) values (17,14,60.50)
insert into math_grade(id,student_id,grade) values (18,14,59.00)

insert into science_grade(id,student_id,grade) values (11,11,100.00)
insert into science_grade(id,student_id,grade) values (12,11,95.00)

insert into science_grade(id,student_id,grade) values (13,12,83.25)
insert into science_grade(id,student_id,grade) values (14,12,79.67)

insert into science_grade(id,student_id,grade) values (15,13,81.80)
insert into science_grade(id,student_id,grade) values (16,13,100.00)

insert into science_grade(id,student_id,grade) values (17,14,60.50)
insert into science_grade(id,student_id,grade) values (18,14,59.00)

insert into history_grade(id,student_id,grade) values (11,11,100.00)
insert into history_grade(id,student_id,grade) values (12,11,95.00)

insert into history_grade(id,student_id,grade) values (13,12,83.25)
insert into history_grade(id,student_id,grade) values (14,12,79.67)

insert into history_grade(id,student_id,grade) values (15,13,81.80)
insert into history_grade(id,student_id,grade) values (16,13,100.00)

insert into history_grade(id,student_id,grade) values (17,14,60.50)
insert into history_grade(id,student_id,grade) values (18,14,59.00)
